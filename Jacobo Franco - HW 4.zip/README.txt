I was help by Professor Neumayer on the Sobel Filter Problem. It seems to be mostly functional.

I made an attempt on the Password Cracker problem, but it it not fully parallelized and there are syntax errors.